package ir.teacher.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class TeacherCommand implements CommandExecutor {
    private final TeacherPlugin plugin;
    private final TeacherManager manager;

    public TeacherCommand(TeacherPlugin plugin, TeacherManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private boolean canTeach(CommandSender s) {
        if (!(s instanceof Player p)) return s.isOp();
        return p.isOp() || manager.isTeacher(p.getUniqueId());
    }

    private boolean canLead(CommandSender s) {
        if (!(s instanceof Player p)) return s.isOp();
        return p.isOp() || manager.isLeader(p.getUniqueId());
    }

    private Player target(CommandSender s, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) s.sendMessage(ChatColor.RED + "بازیکن آنلاین نیست.");
        return p;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(ChatColor.AQUA + "=== TeacherPlugin ===");
            s.sendMessage("/teacher add <player> - افزودن معلم");
            s.sendMessage("/teacher leader <player> - افزودن لیدر معلم");
            s.sendMessage("/teacher remove <player> - حذف نقش معلم");
            s.sendMessage("/teacher points [player] - امتیاز");
            s.sendMessage("/teacher givepoints <player> <amount> - امتیاز دادن");
            s.sendMessage("/teacher school create <name> - ساخت مدرسه");
            s.sendMessage("/teacher school join <name> <player> - افزودن دانش‌آموز");
            s.sendMessage("/teacher diploma [player] - مدرک");
            return true;
        }

        String sub = a[0].toLowerCase();

        if (sub.equals("add")) {
            if (!canLead(s)) { s.sendMessage(ChatColor.RED + "فقط ادمین یا لیدر معلم."); return true; }
            if (a.length < 2) return false;
            Player p = target(s, a[1]); if (p == null) return true;
            manager.addTeacher(p);
            s.sendMessage(ChatColor.GREEN + p.getName() + " اکنون معلم است.");
            return true;
        }

        if (sub.equals("leader")) {
            if (!s.isOp()) { s.sendMessage(ChatColor.RED + "فقط ادمین می‌تواند لیدر معلم اضافه کند."); return true; }
            if (a.length < 2) return false;
            Player p = target(s, a[1]); if (p == null) return true;
            manager.addLeader(p);
            s.sendMessage(ChatColor.GOLD + p.getName() + " اکنون لیدر معلم است.");
            return true;
        }

        if (sub.equals("remove")) {
            if (!canLead(s)) { s.sendMessage(ChatColor.RED + "فقط ادمین یا لیدر معلم."); return true; }
            if (a.length < 2) return false;
            Player p = target(s, a[1]); if (p == null) return true;
            manager.removeTeacher(p);
            s.sendMessage(ChatColor.YELLOW + "نقش معلم از " + p.getName() + " حذف شد.");
            return true;
        }

        if (sub.equals("points")) {
            if (a.length >= 2) {
                Player p = target(s, a[1]); if (p == null) return true;
                s.sendMessage(ChatColor.AQUA + p.getName() + ": " + manager.getPoints(p.getUniqueId()) + " امتیاز");
            } else if (s instanceof Player p) {
                s.sendMessage(ChatColor.AQUA + "امتیاز شما: " + manager.getPoints(p.getUniqueId()));
            }
            return true;
        }

        if (sub.equals("givepoints")) {
            if (!canTeach(s)) { s.sendMessage(ChatColor.RED + "فقط معلم، لیدر معلم یا ادمین."); return true; }
            if (a.length < 3) return false;
            Player p = target(s, a[1]); if (p == null) return true;
            try {
                int amount = Integer.parseInt(a[2]);
                manager.addPoints(p.getUniqueId(), amount);
                s.sendMessage(ChatColor.GREEN + amount + " امتیاز به " + p.getName() + " داده شد.");
            } catch (NumberFormatException e) {
                s.sendMessage(ChatColor.RED + "مقدار امتیاز باید عدد باشد.");
            }
            return true;
        }

        if (sub.equals("diploma")) {
            Player p = a.length >= 2 ? target(s, a[1]) : (s instanceof Player ? (Player)s : null);
            if (p == null) return true;
            s.sendMessage(ChatColor.GOLD + "مدرک " + p.getName() + ": " + manager.diploma(p.getUniqueId()));
            return true;
        }

        if (sub.equals("school")) {
            if (!canLead(s) && !canTeach(s)) { s.sendMessage(ChatColor.RED + "فقط معلم یا لیدر معلم."); return true; }
            if (a.length < 3) {
                s.sendMessage("/teacher school create <name>");
                s.sendMessage("/teacher school join <name> <player>");
                return true;
            }
            String action = a[1].toLowerCase();
            if (action.equals("create")) {
                manager.getSchools().putIfAbsent(a[2], new java.util.HashSet<>());
                s.sendMessage(ChatColor.GREEN + "مدرسه " + a[2] + " ساخته شد.");
                return true;
            }
            if (action.equals("join") && a.length >= 4) {
                Player p = target(s, a[3]); if (p == null) return true;
                var school = manager.getSchools().computeIfAbsent(a[2], k -> new java.util.HashSet<>());
                school.add(p.getUniqueId());
                s.sendMessage(ChatColor.GREEN + p.getName() + " به مدرسه " + a[2] + " اضافه شد.");
                return true;
            }
        }

        s.sendMessage(ChatColor.RED + "دستور ناشناخته است.");
        return true;
    }
}
