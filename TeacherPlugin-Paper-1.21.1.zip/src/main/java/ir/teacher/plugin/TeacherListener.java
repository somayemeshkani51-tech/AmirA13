package ir.teacher.plugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class TeacherListener implements Listener {
    private final TeacherManager manager;
    public TeacherListener(TeacherManager manager) { this.manager = manager; }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        manager.updateTeam(e.getPlayer());
    }
}
