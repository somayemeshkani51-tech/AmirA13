package ir.teacher.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class TeacherManager {
    private final TeacherPlugin plugin;
    private final Set<UUID> teachers = new HashSet<>();
    private final Set<UUID> leaders = new HashSet<>();
    private final Map<UUID, Integer> points = new HashMap<>();
    private final Map<String, Set<UUID>> schools = new HashMap<>();

    public TeacherManager(TeacherPlugin plugin) {
        this.plugin = plugin;
        setupTeams();
    }

    private void setupTeams() {
        var board = Bukkit.getScoreboardManager().getMainScoreboard();
        Team teacher = board.getTeam("teacher");
        if (teacher == null) teacher = board.registerNewTeam("teacher");
        teacher.setPrefix(ChatColor.AQUA + "[TEACHER] " + ChatColor.RESET);

        Team leader = board.getTeam("leaderteacher");
        if (leader == null) leader = board.registerNewTeam("leaderteacher");
        leader.setPrefix(ChatColor.GOLD + "[LEADER-TEACHER] " + ChatColor.RESET);
    }

    public boolean isTeacher(UUID id) { return teachers.contains(id) || leaders.contains(id); }
    public boolean isLeader(UUID id) { return leaders.contains(id); }

    public void addTeacher(Player p) {
        leaders.remove(p.getUniqueId());
        teachers.add(p.getUniqueId());
        updateTeam(p);
    }

    public void addLeader(Player p) {
        teachers.remove(p.getUniqueId());
        leaders.add(p.getUniqueId());
        updateTeam(p);
    }

    public void removeTeacher(Player p) {
        teachers.remove(p.getUniqueId());
        leaders.remove(p.getUniqueId());
        updateTeam(p);
    }

    public void updateTeam(Player p) {
        var board = Bukkit.getScoreboardManager().getMainScoreboard();
        Team t = board.getTeam("teacher");
        Team l = board.getTeam("leaderteacher");
        if (t != null) t.removeEntry(p.getName());
        if (l != null) l.removeEntry(p.getName());

        if (isLeader(p.getUniqueId())) l.addEntry(p.getName());
        else if (isTeacher(p.getUniqueId())) t.addEntry(p.getName());
    }

    public int getPoints(UUID id) { return points.getOrDefault(id, 0); }
    public void addPoints(UUID id, int amount) { points.put(id, Math.max(0, getPoints(id) + amount)); }

    public String diploma(UUID id) {
        int p = getPoints(id);
        if (p >= plugin.getConfig().getInt("diplomas.master", 1000)) return "فوق لیسانس";
        if (p >= plugin.getConfig().getInt("diplomas.bachelor", 600)) return "لیسانس";
        if (p >= plugin.getConfig().getInt("diplomas.associate", 300)) return "فوق دیپلم";
        if (p >= plugin.getConfig().getInt("diplomas.diploma", 100)) return "دیپلم";
        return "بدون مدرک";
    }

    public Map<String, Set<UUID>> getSchools() { return schools; }
}
