package ir.teacher.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class TeacherPlugin extends JavaPlugin {
    private TeacherManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new TeacherManager(this);
        getCommand("teacher").setExecutor(new TeacherCommand(this, manager));
        getCommand("teacher").setTabCompleter(new TeacherTabCompleter());
        getServer().getPluginManager().registerEvents(new TeacherListener(manager), this);
        getLogger().info("TeacherPlugin enabled!");
    }

    public TeacherManager getManager() {
        return manager;
    }
}
