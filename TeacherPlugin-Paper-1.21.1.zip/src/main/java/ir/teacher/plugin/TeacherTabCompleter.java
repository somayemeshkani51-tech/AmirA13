package ir.teacher.plugin;

import org.bukkit.command.*;
import java.util.*;

public class TeacherTabCompleter implements TabCompleter {
    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return List.of("add","leader","remove","points","givepoints","diploma","school");
        if (args.length == 2 && args[0].equalsIgnoreCase("school")) return List.of("create","join");
        return Collections.emptyList();
    }
}
